import './bootstrap';

import {createApp} from 'vue'

import App from './Vue/App.vue'

createApp(App).mount("#app")
